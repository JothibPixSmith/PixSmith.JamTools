self.assetsManifest = {
  "version": "EpAe5sQT",
  "assets": [
    {
      "hash": "sha256-s2InkWKGgJIxOnNVvjsQp510mpXfUY8lgmElyLAyDXQ=",
      "url": "PixSmith.Web.JamTools.styles.css"
    },
    {
      "hash": "sha256-eZu89gqg6eRv4epzgD61J1Aqm1JQXbMiz+DTTA9Vvqk=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Accordion/FluentAccordionItem.razor.js"
    },
    {
      "hash": "sha256-b9RSPukLvSHekr3kftcukF9Hbr4g1a5l0/cfyJ61XMA=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Anchor/FluentAnchor.razor.js"
    },
    {
      "hash": "sha256-3TSUe9IzjOSHGNa2Ix54cmHWEhxMfT5lWU0rFSHOyCA=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/AnchoredRegion/FluentAnchoredRegion.razor.js"
    },
    {
      "hash": "sha256-8QTQtCTbbHkwqt3rAy8ZPjez2lZ6PGmR5Il+7Q3g/rs=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Button/FluentButton.razor.js"
    },
    {
      "hash": "sha256-gVrV4WI8finQdUGG7EIZIAh2tTbFW0GF7Hl73l/1JnE=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Checkbox/FluentCheckbox.razor.js"
    },
    {
      "hash": "sha256-eVIO/6Jn4XBhrPxEYuoZMyoeR/3B0nIi2g+eLmfzoOU=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/DataGrid/FluentDataGrid.razor.js"
    },
    {
      "hash": "sha256-RRtMKgoCUAcrYnPhnEvB6ZTxWToYnajdblfvl3aVTBI=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/DateTime/FluentTimePicker.razor.js"
    },
    {
      "hash": "sha256-cZpvuEtd1kCEHlM6AxhN1/ycVBQCToFb61YoGQ7jm5k=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/DesignSystemProvider/FluentDesignTheme.razor.js"
    },
    {
      "hash": "sha256-EA2+gV7KUYvlKxcD9gBrvwQCj2ABhtLast89kFNa3Ko=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Dialog/FluentDialogProvider.razor.js"
    },
    {
      "hash": "sha256-CndcCP/YVXs68LoE68COc38ypIJenMbJyu+fR0/ZIPc=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Divider/FluentDivider.razor.js"
    },
    {
      "hash": "sha256-V4iZz/kay7SoC/eRuDViVZkhxiL1oNW1gzMAFC6k/wY=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Grid/FluentGrid.razor.js"
    },
    {
      "hash": "sha256-yf+15AR63QV4X8XvrAMxrEP5sX3Ea0tuh+Tsinb6yXU=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/HorizontalScroll/FluentHorizontalScroll.razor.js"
    },
    {
      "hash": "sha256-m9D6O5smUPMQWbjax0bH03XYtdI3RD5geOwhizeT+gE=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/InputFile/FluentInputFile.razor.js"
    },
    {
      "hash": "sha256-FZGwgg/Fe8ELqXyr1DYZqj8mGXrXeZmbCkwOLwf4Jws=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/KeyCode/FluentKeyCode.razor.js"
    },
    {
      "hash": "sha256-hXPNDHD1hTdz/sH1cD60f/ehIklf8zQAEE73UZNGtu8=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Label/FluentInputLabel.razor.js"
    },
    {
      "hash": "sha256-UqhS6+yvd9UrhzFAffmgk2ludr5ck9udmNEHb5mvchc=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/List/FluentAutocomplete.razor.js"
    },
    {
      "hash": "sha256-OqLCO17dCq/aFFg8O0mXN/fF4czXAd6R+vgnYjtdPwc=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/List/FluentCombobox.razor.js"
    },
    {
      "hash": "sha256-/lFyXHGb/lh02BDFUuMzwbfU+zNOdnw2s2zKSrTtW00=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/List/ListComponentBase.razor.js"
    },
    {
      "hash": "sha256-23+bfaqn81VwvCVPcRdX88tfObgAWPZcQfJmx1ohZYE=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Menu/FluentMenu.razor.js"
    },
    {
      "hash": "sha256-u3HANg4jObqKg1Jso4ovjOp2lKuYeAN0+zlRIfKuHhw=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/NavMenu/FluentNavMenu.razor.js"
    },
    {
      "hash": "sha256-hVi+eZ1AhYzWA2HILBTSjl5xstub4DMGzUxGJIQgjVo=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Overflow/FluentOverflow.razor.js"
    },
    {
      "hash": "sha256-IDySDi264SKaXFu1nL+hU2NeFhEMrX6Zv7ubUPR88VI=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Overlay/FluentOverlay.razor.js"
    },
    {
      "hash": "sha256-xlA5fSAkA6TiFUznwHP835N8kAxJ7YJ5MTizYCGeOfo=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/PullToRefresh/FluentPullToRefresh.razor.js"
    },
    {
      "hash": "sha256-FpN8ZcuZyVhdYb+cHNB4VZ5bLM+yi3gDaTZbWsahaYE=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Search/FluentSearch.razor.js"
    },
    {
      "hash": "sha256-TAnVg0aJviMtvE8pWYaaZahF5suJcjonGCC7accq76k=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Slider/FluentSlider.razor.js"
    },
    {
      "hash": "sha256-Em8bsrj69skLLR4IHVJ8lIJTR1EcY/U9nvcfn9t1rzo=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Slider/FluentSliderLabel.razor.js"
    },
    {
      "hash": "sha256-rBxLYd0QGHwfD9IZljh74Lf+ZC+zqoRLqwikRKcRgpg=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/SortableList/FluentSortableList.razor.js"
    },
    {
      "hash": "sha256-kExJSsKpmByqtTJ/TOwptCU5yawR+13aqkZxoVN+a1A=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Splitter/FluentMultiSplitter.razor.js"
    },
    {
      "hash": "sha256-Kh0YI9vhH0m+YJJvQVdOvtm0zuIIGEdRv3aH6iv7Gcg=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Tabs/FluentTab.razor.js"
    },
    {
      "hash": "sha256-YXiMRc9QPIiDSy+mlSF6DtYiSYb3X+1xlsCmrMrE2IU=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/TextField/FluentTextField.razor.js"
    },
    {
      "hash": "sha256-s2w5uif33eV2OeQRoRzZYM1ANZXb6He68mkQ3IZw9Bc=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Toolbar/FluentToolbar.razor.js"
    },
    {
      "hash": "sha256-pWY0aUTl5SagZBQwX/+DOHxke3fHSPoZdTQXbRQSFTU=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Tooltip/FluentTooltip.razor.js"
    },
    {
      "hash": "sha256-YoZrxlLi3FK+1wJX/azJ4txsplMIAW4NbWMb4kI16Tc=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Microsoft.FluentUI.AspNetCore.Components.ewdlgswx1m.bundle.scp.css"
    },
    {
      "hash": "sha256-kXoVJYWXAaKRmlbeYCi7ruHaV6Z2gky3cH2L8p0CcPE=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Microsoft.FluentUI.AspNetCore.Components.lib.module.js"
    },
    {
      "hash": "sha256-gD29yOMICDIiYM16Dl8m2EwS2lyds8DoFkgTy29qko4=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Microsoft.FluentUI.AspNetCore.Components.lib.module.js.LEGAL.txt"
    },
    {
      "hash": "sha256-gEsAhDtb6U0KMwPlbT4fbcWPw5sEF2etLepr/Staxv8=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Microsoft.FluentUI.AspNetCore.Components.lib.module.js.map"
    },
    {
      "hash": "sha256-2wyFQ9++b6uYwv3gv265xtRV2OWnPQMN68NpUHffScU=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/css/reboot.css"
    },
    {
      "hash": "sha256-L9w4Nw5htE5XBWcy0I11eRfWwkTxtN8VSJWnitKu30Q=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/js/initializersLoader.webview.js"
    },
    {
      "hash": "sha256-nAfxgNZU9YZJHIhvgTrKnZuE3e+Nm6C4aEFLwA+NTUk=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/js/loading-theme.js"
    },
    {
      "hash": "sha256-Kj+16eWTS2VnE6K993LtteZYzTs2CFHCGsZZac2+7tQ=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.y2c8wgvkpi.wasm"
    },
    {
      "hash": "sha256-G9WDeRf7Amu7ERjcZHDkZ4bk6vd1hC26bWJxoR9esLM=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.dmkyqdi3du.wasm"
    },
    {
      "hash": "sha256-P8RgR5XY2/k0WwRhFdxBlBRrNCOz2PeYVnaHu/RxHpk=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.370xlgpl9m.wasm"
    },
    {
      "hash": "sha256-tUmz2Of+3OaXNbXlqaRzgKQPjbAiwgmfYpBvDOf49oE=",
      "url": "_framework/Microsoft.AspNetCore.Components.r4ej0yaqox.wasm"
    },
    {
      "hash": "sha256-I1V6RT2jU36RMO/udOCdtpwqRuricdlZ0IRsQvGrIKQ=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.9hvqdnyedj.wasm"
    },
    {
      "hash": "sha256-R8Rvf+ufvlMX05PSWGUXwGm3hty6uCI9EtqBH2FpDIQ=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.vejc7kiu4g.wasm"
    },
    {
      "hash": "sha256-UUwnFUGVKcfnwTDp5d2PPIYvZb3p3cZn9VEABGLlYu8=",
      "url": "_framework/Microsoft.Extensions.Configuration.b5r9igf1ej.wasm"
    },
    {
      "hash": "sha256-m9k4pt1S3OsB7nhPn3Spu1JjG5ixGwaWDws5UBzaZjs=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.3ajkzukr0v.wasm"
    },
    {
      "hash": "sha256-mF9oQ9xLGjMQJj8/e1WnDpTNMHoVOz+RXmX+7azZmrk=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.wmuqa23q8e.wasm"
    },
    {
      "hash": "sha256-Ir1rJOvbjHOV+6r76KVtXZAiNPXIHzjyYlSOI3FVbyQ=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.ybf5ey179d.wasm"
    },
    {
      "hash": "sha256-Nw6fMz9mMm8SS3pPrUsobEC9zzLKC6AKDJhHRldk9VA=",
      "url": "_framework/Microsoft.Extensions.Logging.zh7psstrkj.wasm"
    },
    {
      "hash": "sha256-WsA7Qa5Zv/QmtZqrIEQLYVSPd55Hdc1S+2J7y4JQBJ8=",
      "url": "_framework/Microsoft.Extensions.Options.2abh528mcf.wasm"
    },
    {
      "hash": "sha256-QeF3pj2LH3LcaB6cg9nSyYQ6/Pf6RbTkLakVnAwVPXo=",
      "url": "_framework/Microsoft.Extensions.Primitives.vga3bvc9pt.wasm"
    },
    {
      "hash": "sha256-1FruUUUva5FFFjT3hDX0KxagH2+nQeIQcUHniCfMw8U=",
      "url": "_framework/Microsoft.FluentUI.AspNetCore.Components.8j6jzg3pov.wasm"
    },
    {
      "hash": "sha256-N8RKL2Eil4ZFxIkWa6Uig12+nRHOstda562q7GCs9fE=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.nsfh695mwg.wasm"
    },
    {
      "hash": "sha256-jMQY/dvs5uRhemYHS9FJ2U/551fHVVFNfoiVX8bIXQQ=",
      "url": "_framework/Microsoft.JSInterop.opjjuvycl4.wasm"
    },
    {
      "hash": "sha256-qNlbRQUQpzRMDoXsu0ZMP0bRIKOqL9AbMIt/6kEMDPQ=",
      "url": "_framework/PixSmith.Web.JamTools.06x76wznlb.wasm"
    },
    {
      "hash": "sha256-kNtk+1CuXXbfyDLOh2QVsDmmmc611i9zbZQisk06srs=",
      "url": "_framework/System.Collections.Concurrent.0wzvxr5cd1.wasm"
    },
    {
      "hash": "sha256-FOO3ZB8cUTGweNmQOZbfUeg9C8MdUROo4TbXEb2OGE4=",
      "url": "_framework/System.Collections.Immutable.c0mu6ffol7.wasm"
    },
    {
      "hash": "sha256-UsF1FPCgau/XQvu7ORzQTOBhh+J1TTZuHE1pY+xkm/E=",
      "url": "_framework/System.Collections.NonGeneric.6qg8sz779f.wasm"
    },
    {
      "hash": "sha256-JzVbtLmuCCPnnc1LUexIJ5qPM7Nn1Czue+ZDCGGNymU=",
      "url": "_framework/System.Collections.Specialized.p4njbhggv9.wasm"
    },
    {
      "hash": "sha256-oRlgcb2MwT6chZw9KHqV4JkxHsFOHdFP8Bj99WDekKg=",
      "url": "_framework/System.Collections.fg9ebt0xx4.wasm"
    },
    {
      "hash": "sha256-G11SAZgvvlQHfte8pCyiLiieSOf3JQMeDagsZuYse8c=",
      "url": "_framework/System.ComponentModel.Primitives.bgpdzmsvyv.wasm"
    },
    {
      "hash": "sha256-cXoa4tKYlm5wuzijI8IHnJHgDZlTgdB9GS431cL+aXw=",
      "url": "_framework/System.ComponentModel.TypeConverter.lvkfbu8fg6.wasm"
    },
    {
      "hash": "sha256-Iz85io38wdEMeNHyrnF9ZPp4ivpyvfU0bWTW1rU2Rwg=",
      "url": "_framework/System.ComponentModel.zshcyi7w4p.wasm"
    },
    {
      "hash": "sha256-IXV20je4C14JknpnlOWYcBem/ZfBmLlfveIcWirp1VE=",
      "url": "_framework/System.Console.l3urkkceh0.wasm"
    },
    {
      "hash": "sha256-s/pVX8itpmtYN2Sv50GJkKk6VLrC8Gy/ore8Ki+T8Yw=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.n3zko97ftx.wasm"
    },
    {
      "hash": "sha256-s6Nya+biDIPla0FDwlzO4RC5+aFc2NRBJVCccxX2txE=",
      "url": "_framework/System.Drawing.Primitives.5yogqc3pip.wasm"
    },
    {
      "hash": "sha256-bvSW4cCARXR3hTS0kQuXYnbiY3MMQFt27+AUYnm9FRM=",
      "url": "_framework/System.Drawing.i76cmty7yw.wasm"
    },
    {
      "hash": "sha256-5NlyiKMjQMJVLZ+E92VHzP4NXkvjJnT4LTZkWqm0KJc=",
      "url": "_framework/System.IO.Pipelines.orwcdf2bqi.wasm"
    },
    {
      "hash": "sha256-5BLxGDwNl/Ai0dIimcO1xlj91jWegRagrDElvlpiAu4=",
      "url": "_framework/System.Linq.Expressions.sm71i9ykix.wasm"
    },
    {
      "hash": "sha256-xGykulCzC0GQLEpFKdc8NNlirhY7/3CkdfYt1fh5we4=",
      "url": "_framework/System.Linq.k223u2kcro.wasm"
    },
    {
      "hash": "sha256-oLRp33zeVPtvsRwIoczoGoNlHTs+QMYkGUbG+vtdypE=",
      "url": "_framework/System.Memory.kji3cubnvm.wasm"
    },
    {
      "hash": "sha256-81w0bB8J2LaGB78t4uc0QBwJBl/y/DN/+exbr9BwAM8=",
      "url": "_framework/System.Net.Http.h39smcctay.wasm"
    },
    {
      "hash": "sha256-V3a4yqX8jFSrhqCnzc62c516pAobIH6RBXqbb37BHsQ=",
      "url": "_framework/System.Net.Primitives.tv3cjivm0r.wasm"
    },
    {
      "hash": "sha256-WyFL1/88A3WW+AWEZi4GuPG4Jp9MDIKjcsjCSv7ncC4=",
      "url": "_framework/System.ObjectModel.19eq01bnm5.wasm"
    },
    {
      "hash": "sha256-DQC7IJ3D2v/Spe52yq77L0kdJi7LVr+OLURKvQSyRMU=",
      "url": "_framework/System.Private.CoreLib.30bhukoihe.wasm"
    },
    {
      "hash": "sha256-O0eIPmidBnk2M5T0gR+/aRHVkAHuqHpvos0mxVRVKLc=",
      "url": "_framework/System.Private.Uri.nthsmyq3ca.wasm"
    },
    {
      "hash": "sha256-Y0ahU4DB6Dt9GtYLhkI7ue/Xab9TIC+WnmSh/O12OsI=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.73jz3ihmmf.wasm"
    },
    {
      "hash": "sha256-Eb6PWNb/o9geVxe8PHYTderJocQsM4pg09S29ydtDCg=",
      "url": "_framework/System.Runtime.thhy5zqg3d.wasm"
    },
    {
      "hash": "sha256-oAiqN4+0rXCP07gQh1D89o9s9TjaMTh1Pgbtm7wEiPg=",
      "url": "_framework/System.Security.Cryptography.ouxcxoa0xa.wasm"
    },
    {
      "hash": "sha256-WWGqU1P7ibS/e2CelqkoMZQa+FhxTzMT6kADSFv4tPw=",
      "url": "_framework/System.Text.Encodings.Web.7kxzi2zh06.wasm"
    },
    {
      "hash": "sha256-Gprg//tU7BldsoMyFinrz0W6+Eb/OePprqMMu2KYAm8=",
      "url": "_framework/System.Text.Json.mlhozacsc5.wasm"
    },
    {
      "hash": "sha256-tsgoNz2G1SRS1L6dSo9nqiztUvGHKwUVS2sw660tr1I=",
      "url": "_framework/System.Text.RegularExpressions.azop2fezew.wasm"
    },
    {
      "hash": "sha256-JRSnUKU4RCZCvwQXVaK87jabHPSnQK1daxG24xvCico=",
      "url": "_framework/System.deed694j9w.wasm"
    },
    {
      "hash": "sha256-3lCWrko3zwspV40aQhs2S/IMkRSarnHRKIdkHhuXIBA=",
      "url": "_framework/blazor.webassembly.66stpp682q.js"
    },
    {
      "hash": "sha256-nZssDT3d4DuPYpXT9MJfBlglUJoz+S0F2r5JYjkz7eM=",
      "url": "_framework/dotnet.7btgkarr1x.js"
    },
    {
      "hash": "sha256-tjie09uavTiX1TnkP9OL+OcnxCOs44ff5Dgws1rnAnc=",
      "url": "_framework/dotnet.native.2mv1pqdd2n.wasm"
    },
    {
      "hash": "sha256-JvdIvkSF0x6euoPT2QnQSMg2Gyv2oJbFeBi1XmWLYFU=",
      "url": "_framework/dotnet.native.69poregybn.js"
    },
    {
      "hash": "sha256-ArknccFM1sHNVcih0x1h52AG+abNCoQjl6BlVrv3ePw=",
      "url": "_framework/dotnet.runtime.q5rqv3xrhm.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-9P6s5+SpvNTbbZ5foijn9SSzEZ/NYnqlhLBNiLnGoz0=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-P5VfYzdP9Lplky2cKkffWHMtq1RnGR+qie2rtmiANBA=",
      "url": "css/input.css"
    },
    {
      "hash": "sha256-DOrmkZYceRxQuU7AcSaIVAZS2aoq2vzPKDNGitMWyAA=",
      "url": "css/output.css"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-CuwBEQpOVQ49lkduc183YOZta6MC54MVjpUYwtb+ld0=",
      "url": "index.html"
    },
    {
      "hash": "sha256-JDpyD39pcudh4OlrntO2uYNwFfdhlyblgq+B8Rs7LIk=",
      "url": "manifest.webmanifest"
    },
    {
      "hash": "sha256-lzB3mTDtTi2aKQ2C0LfFnSyBNpDJDarpsGbURzfqxjY=",
      "url": "package-lock.json"
    },
    {
      "hash": "sha256-Nz0sbvHlkn6ZnBWPC5MofYRLQ6itdCee6Me4XP+Yc6A=",
      "url": "package.json"
    }
  ]
};
