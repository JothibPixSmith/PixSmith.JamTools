self.assetsManifest = {
  "version": "BnwnOU/B",
  "assets": [
    {
      "hash": "sha256-s2InkWKGgJIxOnNVvjsQp510mpXfUY8lgmElyLAyDXQ=",
      "url": "PixSmith.Web.JamTools.styles.css"
    },
    {
      "hash": "sha256-eZu89gqg6eRv4epzgD61J1Aqm1JQXbMiz+DTTA9Vvqk=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Accordion/FluentAccordionItem.razor.js"
    },
    {
      "hash": "sha256-b9RSPukLvSHekr3kftcukF9Hbr4g1a5l0/cfyJ61XMA=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Anchor/FluentAnchor.razor.js"
    },
    {
      "hash": "sha256-3TSUe9IzjOSHGNa2Ix54cmHWEhxMfT5lWU0rFSHOyCA=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/AnchoredRegion/FluentAnchoredRegion.razor.js"
    },
    {
      "hash": "sha256-8QTQtCTbbHkwqt3rAy8ZPjez2lZ6PGmR5Il+7Q3g/rs=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Button/FluentButton.razor.js"
    },
    {
      "hash": "sha256-gVrV4WI8finQdUGG7EIZIAh2tTbFW0GF7Hl73l/1JnE=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Checkbox/FluentCheckbox.razor.js"
    },
    {
      "hash": "sha256-eVIO/6Jn4XBhrPxEYuoZMyoeR/3B0nIi2g+eLmfzoOU=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/DataGrid/FluentDataGrid.razor.js"
    },
    {
      "hash": "sha256-RRtMKgoCUAcrYnPhnEvB6ZTxWToYnajdblfvl3aVTBI=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/DateTime/FluentTimePicker.razor.js"
    },
    {
      "hash": "sha256-cZpvuEtd1kCEHlM6AxhN1/ycVBQCToFb61YoGQ7jm5k=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/DesignSystemProvider/FluentDesignTheme.razor.js"
    },
    {
      "hash": "sha256-EA2+gV7KUYvlKxcD9gBrvwQCj2ABhtLast89kFNa3Ko=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Dialog/FluentDialogProvider.razor.js"
    },
    {
      "hash": "sha256-CndcCP/YVXs68LoE68COc38ypIJenMbJyu+fR0/ZIPc=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Divider/FluentDivider.razor.js"
    },
    {
      "hash": "sha256-V4iZz/kay7SoC/eRuDViVZkhxiL1oNW1gzMAFC6k/wY=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Grid/FluentGrid.razor.js"
    },
    {
      "hash": "sha256-yf+15AR63QV4X8XvrAMxrEP5sX3Ea0tuh+Tsinb6yXU=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/HorizontalScroll/FluentHorizontalScroll.razor.js"
    },
    {
      "hash": "sha256-m9D6O5smUPMQWbjax0bH03XYtdI3RD5geOwhizeT+gE=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/InputFile/FluentInputFile.razor.js"
    },
    {
      "hash": "sha256-FZGwgg/Fe8ELqXyr1DYZqj8mGXrXeZmbCkwOLwf4Jws=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/KeyCode/FluentKeyCode.razor.js"
    },
    {
      "hash": "sha256-hXPNDHD1hTdz/sH1cD60f/ehIklf8zQAEE73UZNGtu8=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Label/FluentInputLabel.razor.js"
    },
    {
      "hash": "sha256-UqhS6+yvd9UrhzFAffmgk2ludr5ck9udmNEHb5mvchc=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/List/FluentAutocomplete.razor.js"
    },
    {
      "hash": "sha256-OqLCO17dCq/aFFg8O0mXN/fF4czXAd6R+vgnYjtdPwc=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/List/FluentCombobox.razor.js"
    },
    {
      "hash": "sha256-/lFyXHGb/lh02BDFUuMzwbfU+zNOdnw2s2zKSrTtW00=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/List/ListComponentBase.razor.js"
    },
    {
      "hash": "sha256-23+bfaqn81VwvCVPcRdX88tfObgAWPZcQfJmx1ohZYE=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Menu/FluentMenu.razor.js"
    },
    {
      "hash": "sha256-u3HANg4jObqKg1Jso4ovjOp2lKuYeAN0+zlRIfKuHhw=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/NavMenu/FluentNavMenu.razor.js"
    },
    {
      "hash": "sha256-hVi+eZ1AhYzWA2HILBTSjl5xstub4DMGzUxGJIQgjVo=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Overflow/FluentOverflow.razor.js"
    },
    {
      "hash": "sha256-IDySDi264SKaXFu1nL+hU2NeFhEMrX6Zv7ubUPR88VI=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Overlay/FluentOverlay.razor.js"
    },
    {
      "hash": "sha256-xlA5fSAkA6TiFUznwHP835N8kAxJ7YJ5MTizYCGeOfo=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/PullToRefresh/FluentPullToRefresh.razor.js"
    },
    {
      "hash": "sha256-FpN8ZcuZyVhdYb+cHNB4VZ5bLM+yi3gDaTZbWsahaYE=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Search/FluentSearch.razor.js"
    },
    {
      "hash": "sha256-TAnVg0aJviMtvE8pWYaaZahF5suJcjonGCC7accq76k=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Slider/FluentSlider.razor.js"
    },
    {
      "hash": "sha256-Em8bsrj69skLLR4IHVJ8lIJTR1EcY/U9nvcfn9t1rzo=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Slider/FluentSliderLabel.razor.js"
    },
    {
      "hash": "sha256-rBxLYd0QGHwfD9IZljh74Lf+ZC+zqoRLqwikRKcRgpg=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/SortableList/FluentSortableList.razor.js"
    },
    {
      "hash": "sha256-kExJSsKpmByqtTJ/TOwptCU5yawR+13aqkZxoVN+a1A=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Splitter/FluentMultiSplitter.razor.js"
    },
    {
      "hash": "sha256-Kh0YI9vhH0m+YJJvQVdOvtm0zuIIGEdRv3aH6iv7Gcg=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Tabs/FluentTab.razor.js"
    },
    {
      "hash": "sha256-YXiMRc9QPIiDSy+mlSF6DtYiSYb3X+1xlsCmrMrE2IU=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/TextField/FluentTextField.razor.js"
    },
    {
      "hash": "sha256-s2w5uif33eV2OeQRoRzZYM1ANZXb6He68mkQ3IZw9Bc=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Toolbar/FluentToolbar.razor.js"
    },
    {
      "hash": "sha256-pWY0aUTl5SagZBQwX/+DOHxke3fHSPoZdTQXbRQSFTU=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Tooltip/FluentTooltip.razor.js"
    },
    {
      "hash": "sha256-YoZrxlLi3FK+1wJX/azJ4txsplMIAW4NbWMb4kI16Tc=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Microsoft.FluentUI.AspNetCore.Components.ewdlgswx1m.bundle.scp.css"
    },
    {
      "hash": "sha256-kXoVJYWXAaKRmlbeYCi7ruHaV6Z2gky3cH2L8p0CcPE=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Microsoft.FluentUI.AspNetCore.Components.lib.module.js"
    },
    {
      "hash": "sha256-gD29yOMICDIiYM16Dl8m2EwS2lyds8DoFkgTy29qko4=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Microsoft.FluentUI.AspNetCore.Components.lib.module.js.LEGAL.txt"
    },
    {
      "hash": "sha256-gEsAhDtb6U0KMwPlbT4fbcWPw5sEF2etLepr/Staxv8=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Microsoft.FluentUI.AspNetCore.Components.lib.module.js.map"
    },
    {
      "hash": "sha256-2wyFQ9++b6uYwv3gv265xtRV2OWnPQMN68NpUHffScU=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/css/reboot.css"
    },
    {
      "hash": "sha256-L9w4Nw5htE5XBWcy0I11eRfWwkTxtN8VSJWnitKu30Q=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/js/initializersLoader.webview.js"
    },
    {
      "hash": "sha256-nAfxgNZU9YZJHIhvgTrKnZuE3e+Nm6C4aEFLwA+NTUk=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/js/loading-theme.js"
    },
    {
      "hash": "sha256-Kj+16eWTS2VnE6K993LtteZYzTs2CFHCGsZZac2+7tQ=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.y2c8wgvkpi.wasm"
    },
    {
      "hash": "sha256-G9WDeRf7Amu7ERjcZHDkZ4bk6vd1hC26bWJxoR9esLM=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.dmkyqdi3du.wasm"
    },
    {
      "hash": "sha256-P8RgR5XY2/k0WwRhFdxBlBRrNCOz2PeYVnaHu/RxHpk=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.370xlgpl9m.wasm"
    },
    {
      "hash": "sha256-tUmz2Of+3OaXNbXlqaRzgKQPjbAiwgmfYpBvDOf49oE=",
      "url": "_framework/Microsoft.AspNetCore.Components.r4ej0yaqox.wasm"
    },
    {
      "hash": "sha256-I1V6RT2jU36RMO/udOCdtpwqRuricdlZ0IRsQvGrIKQ=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.9hvqdnyedj.wasm"
    },
    {
      "hash": "sha256-R8Rvf+ufvlMX05PSWGUXwGm3hty6uCI9EtqBH2FpDIQ=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.vejc7kiu4g.wasm"
    },
    {
      "hash": "sha256-UUwnFUGVKcfnwTDp5d2PPIYvZb3p3cZn9VEABGLlYu8=",
      "url": "_framework/Microsoft.Extensions.Configuration.b5r9igf1ej.wasm"
    },
    {
      "hash": "sha256-m9k4pt1S3OsB7nhPn3Spu1JjG5ixGwaWDws5UBzaZjs=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.3ajkzukr0v.wasm"
    },
    {
      "hash": "sha256-mF9oQ9xLGjMQJj8/e1WnDpTNMHoVOz+RXmX+7azZmrk=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.wmuqa23q8e.wasm"
    },
    {
      "hash": "sha256-Ir1rJOvbjHOV+6r76KVtXZAiNPXIHzjyYlSOI3FVbyQ=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.ybf5ey179d.wasm"
    },
    {
      "hash": "sha256-Nw6fMz9mMm8SS3pPrUsobEC9zzLKC6AKDJhHRldk9VA=",
      "url": "_framework/Microsoft.Extensions.Logging.zh7psstrkj.wasm"
    },
    {
      "hash": "sha256-WsA7Qa5Zv/QmtZqrIEQLYVSPd55Hdc1S+2J7y4JQBJ8=",
      "url": "_framework/Microsoft.Extensions.Options.2abh528mcf.wasm"
    },
    {
      "hash": "sha256-QeF3pj2LH3LcaB6cg9nSyYQ6/Pf6RbTkLakVnAwVPXo=",
      "url": "_framework/Microsoft.Extensions.Primitives.vga3bvc9pt.wasm"
    },
    {
      "hash": "sha256-09aMYGs9uKjdCaEAUctPMTlvQCLmM9vtPOqzq+G9V/o=",
      "url": "_framework/Microsoft.FluentUI.AspNetCore.Components.9ho1v6en1f.wasm"
    },
    {
      "hash": "sha256-N8RKL2Eil4ZFxIkWa6Uig12+nRHOstda562q7GCs9fE=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.nsfh695mwg.wasm"
    },
    {
      "hash": "sha256-jMQY/dvs5uRhemYHS9FJ2U/551fHVVFNfoiVX8bIXQQ=",
      "url": "_framework/Microsoft.JSInterop.opjjuvycl4.wasm"
    },
    {
      "hash": "sha256-rGVlqqqpyOadymdwwxit5TE/bDtB0xyvrRbj9br4b0M=",
      "url": "_framework/PixSmith.Web.JamTools.siffa9l9v5.wasm"
    },
    {
      "hash": "sha256-y7NnWh8z8gPuKAQI4hhBL69y2e7NlYbHZDvyDbFBTHI=",
      "url": "_framework/System.1h5i8a3bq8.wasm"
    },
    {
      "hash": "sha256-l02kFT1JY0oElRJkrtiViR8ptnckpJ6IAPpRpxPtfoU=",
      "url": "_framework/System.Collections.7cijawagvm.wasm"
    },
    {
      "hash": "sha256-3QHql812H7vuGXXzl42ek/wm9hik+yC07DWzw1nk+QU=",
      "url": "_framework/System.Collections.Concurrent.7ni7k4cvb3.wasm"
    },
    {
      "hash": "sha256-EmOwAbF6FzuZoUvAA3HdT/hDAZyPLY+QryIlBFhqPek=",
      "url": "_framework/System.Collections.Immutable.yjair7ikwi.wasm"
    },
    {
      "hash": "sha256-A0dcDY0sgI1GSeSqRm/rQ57HOTDdAxdrEV+aAGFYXAg=",
      "url": "_framework/System.Collections.NonGeneric.j0f0f7hsu1.wasm"
    },
    {
      "hash": "sha256-GLOSipcDQMCJ/t8EqAL1j0pQoctSLhRAzBxRdMjZK28=",
      "url": "_framework/System.Collections.Specialized.w2k9zverge.wasm"
    },
    {
      "hash": "sha256-Ff6no+SGgaLJezbf9okKz02n4uaG2GOP7TeA5xQlQTE=",
      "url": "_framework/System.ComponentModel.Primitives.fzzz9qxwao.wasm"
    },
    {
      "hash": "sha256-bFxXSrCNIHDut3krKhvdTCR/b1/GRZOLvp4GrxGAquk=",
      "url": "_framework/System.ComponentModel.TypeConverter.01z9uzkke5.wasm"
    },
    {
      "hash": "sha256-gROd1mGPH8FaEgzh0nUJBEL8MD/doQc5GIW6YJYD3W4=",
      "url": "_framework/System.ComponentModel.tpqldnnl29.wasm"
    },
    {
      "hash": "sha256-NO3BtfRNYXJdcEfPBalyLpva2EHuH0zpv0aokOEHr4o=",
      "url": "_framework/System.Console.4kydlmvr8i.wasm"
    },
    {
      "hash": "sha256-a9xySI3pQb5O5z6LM69NGTRs5NJf4xuZuWo27NFAMg4=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.n1f1mtbve3.wasm"
    },
    {
      "hash": "sha256-hkD2cBvc7KGe7GbZMJApPl2zVuzryFH2AhRRW2WY6qA=",
      "url": "_framework/System.Drawing.Primitives.2yfbyqldkv.wasm"
    },
    {
      "hash": "sha256-c9pRUnCUqJLySsnyKF8aIIgBblXc5tHkY3F90RfmEHM=",
      "url": "_framework/System.Drawing.xvt9y59s01.wasm"
    },
    {
      "hash": "sha256-YUHUP3fb8mUiEFOdfQqM/stc3OxmfyDdEIl8P1n6F5o=",
      "url": "_framework/System.IO.Pipelines.9azjszgsci.wasm"
    },
    {
      "hash": "sha256-VBiWDukwPmb4qmKLtFAxlFYwFTAVrJeVsMhyXZiMQ7M=",
      "url": "_framework/System.Linq.81cvlxw122.wasm"
    },
    {
      "hash": "sha256-MZM7FtvRAzQYVdv+SMjKLlxJsb4AMrGH44C15xh/d4I=",
      "url": "_framework/System.Linq.Expressions.142icjknoh.wasm"
    },
    {
      "hash": "sha256-k5oBrRF+vMI3d0bq5j3UKTiRwfdT3IsawK1+/nPDXiw=",
      "url": "_framework/System.Memory.bikruznpie.wasm"
    },
    {
      "hash": "sha256-+VK0oog1iYK++20JEKFfV86RXQVq4PxthNzhqxD7348=",
      "url": "_framework/System.Net.Http.no9gk5pvk1.wasm"
    },
    {
      "hash": "sha256-uNMRzGCCBXqGI3HTb7YrMeyQ+KHjgAFw9ORRsZYDAKI=",
      "url": "_framework/System.Net.Primitives.kxpg9rp39o.wasm"
    },
    {
      "hash": "sha256-Wr7uYK5IAEEBz//fnLFv8YNhN9O4z269rzOcImH8Yqk=",
      "url": "_framework/System.ObjectModel.2ue58bdwtg.wasm"
    },
    {
      "hash": "sha256-F0E2wl0fv/oOdzaQwb8pLcjkCmyLOduWip3hKY/QsFc=",
      "url": "_framework/System.Private.CoreLib.fu5q147w2b.wasm"
    },
    {
      "hash": "sha256-aWFAF83uAvYBZAeVeDMt+YoS4yMc2acYDvECntnLLZA=",
      "url": "_framework/System.Private.Uri.xmrixdrt3x.wasm"
    },
    {
      "hash": "sha256-KZbAOVO7hDpvWIBk6lVcIm7F51GBXTAqtpI3O9USW1g=",
      "url": "_framework/System.Runtime.90amiub2ik.wasm"
    },
    {
      "hash": "sha256-pGYNj0GobLeGcJ171gYL46dLUm4II/UNtKByEtRPIyI=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.4euq9hr5ei.wasm"
    },
    {
      "hash": "sha256-9oHjLDAHVcIqywd/PNY5orqmLFtxqM3BXwnhHntnvjQ=",
      "url": "_framework/System.Security.Cryptography.2lkfgnu7ed.wasm"
    },
    {
      "hash": "sha256-A6Y/ybU87Z9uWmf4GzzcF2Q9rnpsZg78wXeT3nJU09M=",
      "url": "_framework/System.Text.Encodings.Web.jgr0b8ttes.wasm"
    },
    {
      "hash": "sha256-LYQme3kBwDPqcy01oaksgeqjE5utseOGI60QDYk0cdQ=",
      "url": "_framework/System.Text.Json.fp01ed6tkn.wasm"
    },
    {
      "hash": "sha256-ggXSdlEwab2hPiwPqodeUbctaGv9A/2wT/z41ewU4T4=",
      "url": "_framework/System.Text.RegularExpressions.yr5d4qzp60.wasm"
    },
    {
      "hash": "sha256-3lCWrko3zwspV40aQhs2S/IMkRSarnHRKIdkHhuXIBA=",
      "url": "_framework/blazor.webassembly.66stpp682q.js"
    },
    {
      "hash": "sha256-us+HU4OPGwdVY9TcSa48QWFQGFsg2DH+iQAunWMqkV4=",
      "url": "_framework/dotnet.e3saj8hcd7.js"
    },
    {
      "hash": "sha256-hYigRhIZKHyCXxXWqL/yR3ZWzZhV2oSi+2N3/UPeoxk=",
      "url": "_framework/dotnet.native.nxw7lo0lh5.wasm"
    },
    {
      "hash": "sha256-RezASHv+dbqV50cFnld76YiLhk4B+BjMAKs/euUdNyE=",
      "url": "_framework/dotnet.native.vzj2a6aakt.js"
    },
    {
      "hash": "sha256-MZMguyke9CroSQl+L/SHIGFkPTD+LtYGXkXjAvwWx40=",
      "url": "_framework/dotnet.runtime.zbexyp8zrs.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-ooWANEFsMFdM5PTrn+ohbplhrG6OL52F2admKh8r69E=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-P5VfYzdP9Lplky2cKkffWHMtq1RnGR+qie2rtmiANBA=",
      "url": "css/input.css"
    },
    {
      "hash": "sha256-DOrmkZYceRxQuU7AcSaIVAZS2aoq2vzPKDNGitMWyAA=",
      "url": "css/output.css"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-/ipubFM3OoavhHgNBPUWJKHTov9BivMkO+hfwi1j0+o=",
      "url": "index.html"
    },
    {
      "hash": "sha256-JDpyD39pcudh4OlrntO2uYNwFfdhlyblgq+B8Rs7LIk=",
      "url": "manifest.webmanifest"
    },
    {
      "hash": "sha256-lzB3mTDtTi2aKQ2C0LfFnSyBNpDJDarpsGbURzfqxjY=",
      "url": "package-lock.json"
    },
    {
      "hash": "sha256-Nz0sbvHlkn6ZnBWPC5MofYRLQ6itdCee6Me4XP+Yc6A=",
      "url": "package.json"
    }
  ]
};
